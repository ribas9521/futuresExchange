exports.fees = {
  futures: {
    maker: 2,
    taker: 4,
    feePrecision: 100
  }
};
exports.leverage = {
  precision: 1
};

exports.position = {
  pnlPrecision: 1000
};

exports.balance = {
  precision: 100000000
};
exports.funding = {
  precision: 100000000
};
